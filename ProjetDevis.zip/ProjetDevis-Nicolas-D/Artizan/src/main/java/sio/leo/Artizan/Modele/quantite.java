package sio.leo.Artizan.Modele;


/** ************************************************************************
 * Source File	:  quantite.java
 * Author                   :  CN
 * Project name         :  Accueil WinDesign V17* Created                 :  30/11/2022
 * Modified   	:  30/11/2022
 * Description	:  Definition of the class quantite
 ************************************************************************* */

import java.util.*;

public class quantite {
    //Inners Classifiers

    //Attributes
    private java.lang.Float quantite_quantite;

    //Attributes Association
    //Operations

    public Float getQuantite_quantite() {
        return quantite_quantite;
    }

    public void setQuantite_quantite(Float quantite_quantite) {
        this.quantite_quantite = quantite_quantite;
    }
    
} //End Class quantite

